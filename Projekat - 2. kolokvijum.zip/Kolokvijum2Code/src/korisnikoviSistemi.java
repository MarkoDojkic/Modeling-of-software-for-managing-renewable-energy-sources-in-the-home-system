import java.util.List;

public class korisnikoviSistemi extends sistemOIE {
	private List<sistemOIE> m_children;

	public List<sistemOIE> getM_children() {
		return m_children;
	}

	public void setM_children(List<sistemOIE> m_children) {
		this.m_children = m_children;
	}
/*
	private Set<sistemOIE> sistemOIE;

	public Set<sistemOIE> getSistemOIE() {
		return sistemOIE;
	}

	public void setSistemOIE(Set<sistemOIE> sistemOIE) {
		this.sistemOIE = sistemOIE;
	}

	private korisnik korisnik;

	public korisnik getKorisnik() {
		return korisnik;
	}

	public void setKorisnik(korisnik korisnik) {
		this.korisnik = korisnik;
	}
*/
	
	public void prikaziPodatke() {
		for (sistemOIE sistem : m_children){
			sistem.prikaziPodatke();
		}
	}

	public korisnikoviSistemi getComposite() {

		return this;
	}

	public korisnikoviSistemi() {
		m_children = new java.util.ArrayList<sistemOIE>();
	}

	public synchronized void addChild(sistemOIE a_component) {

		synchronized (a_component) {
			m_children.add(a_component);
			a_component.setParent(this);
		}

	}

	public sistemOIE getChild(int a_childIndex) {

		return (sistemOIE) m_children.get(a_childIndex);

	}

	public synchronized void removeChild(sistemOIE a_component) {

		synchronized (a_component) {
			if (this == a_component.getParent()) {
				a_component.setParent(null);
			}
			m_children.remove(a_component);
		}

	}
}