public abstract class sistemOIE {
	
	public abstract void prikaziPodatke();

	private sistemOIE m_parent;

	public sistemOIE getParent() {

		return m_parent;
	}

	public void setParent(sistemOIE a_parent) {

		m_parent = a_parent;
	}

	public abstract korisnikoviSistemi getComposite();
	
}