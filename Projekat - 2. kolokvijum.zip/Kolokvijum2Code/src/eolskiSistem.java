public class eolskiSistem extends sistemOIE {
	
	private int id_sistema, brojObrtaja, radniNapon;
	private double jacinaStruje, ukupnaProizvedenaSnaga;
	private boolean je_aktivan;
	
	public eolskiSistem(int id_sistema, int brojObrtaja, int radniNapon,
			double jacinaStruje, double ukupnaProizvedenaSnaga,
			boolean je_aktivan) {
		super();
		this.id_sistema = id_sistema;
		this.brojObrtaja = brojObrtaja;
		this.radniNapon = radniNapon;
		this.jacinaStruje = jacinaStruje;
		this.ukupnaProizvedenaSnaga = ukupnaProizvedenaSnaga;
		this.je_aktivan = je_aktivan;
	}

	public int getId_sistema() {
		return id_sistema;
	}

	public void setId_sistema(int id_sistema) {
		this.id_sistema = id_sistema;
	}

	public double getRadniNapon() {
		return radniNapon;
	}

	public void setRadniNapon(int radniNapon) {
		this.radniNapon = radniNapon;
	}

	public int getBrojObrtaja() {
		return brojObrtaja;
	}

	public void setBrojObrtaja(int brojObrtaja) {
		this.brojObrtaja = brojObrtaja;
	}

	public double getJacinaStruje() {
		return jacinaStruje;
	}

	public void setJacinaStruje(double jacinaStruje) {
		this.jacinaStruje = jacinaStruje;
	}

	public double getUkupnaProizvedenaSnaga() {
		return ukupnaProizvedenaSnaga;
	}

	public void setUkupnaProizvedenaSnaga(double ukupnaProizvedenaSnaga) {
		this.ukupnaProizvedenaSnaga = ukupnaProizvedenaSnaga;
	}

	public boolean getJe_aktivan() {
		return je_aktivan;
	}

	public void setJe_aktivan(boolean je_aktivan) {
		this.je_aktivan = je_aktivan;
	}

	public void prikaziPodatke() {
		System.out.println("---------------------");
		System.out.println("Eolski sistem #" + this.getId_sistema());
		System.out.println("Radni napon: " + this.getRadniNapon() + "V");
		System.out.println("Jacina struje: " + this.getJacinaStruje() + "A");
		System.out.println("Broj obrtaja: " + this.getBrojObrtaja() + " rpm");
		System.out.println("Ukupna proizvodnja: " + this.getUkupnaProizvedenaSnaga()/1000 + " kWh");
		System.out.println("Status sistema: " + (this.getJe_aktivan() ? "AKTIVAN" : "NEAKTIVAN"));
		System.out.println("---------------------");
	}

	public korisnikoviSistemi getComposite() {
		return null;
	}
}