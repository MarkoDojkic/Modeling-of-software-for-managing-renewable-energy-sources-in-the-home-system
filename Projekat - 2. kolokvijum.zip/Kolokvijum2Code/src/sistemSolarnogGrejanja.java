public class sistemSolarnogGrejanja extends sistemOIE {
	
	private int id_sistema;
	private double trenutniProtokVode, trenutnaTemperaturaVode;
	private boolean je_potrebnoDopunitiFreon, je_aktivan;
	
	public sistemSolarnogGrejanja(int id_sistema, double trenutniProtokVode,
			double trenutnaTemperaturaVode, boolean je_potrebnoDopunitiFreon,
			boolean je_aktivan) {
		super();
		this.id_sistema = id_sistema;
		this.trenutniProtokVode = trenutniProtokVode;
		this.trenutnaTemperaturaVode = trenutnaTemperaturaVode;
		this.je_potrebnoDopunitiFreon = je_potrebnoDopunitiFreon;
		this.je_aktivan = je_aktivan;
	}

	public int getId_sistema() {
		return id_sistema;
	}

	public void setId_sistema(int id_sistema) {
		this.id_sistema = id_sistema;
	}

	public double getTrenutniProtokVode() {
		return trenutniProtokVode;
	}

	public void setTrenutniProtokVode(double trenutniProtokVode) {
		this.trenutniProtokVode = trenutniProtokVode;
	}

	public double getTrenutnaTemperaturaVode() {
		return trenutnaTemperaturaVode;
	}

	public void setTrenutnaTemperaturaVode(double trenutnaTemperaturaVode) {
		this.trenutnaTemperaturaVode = trenutnaTemperaturaVode;
	}

	public boolean getJe_potrebnoDopunitiFreon() {
		return je_potrebnoDopunitiFreon;
	}

	public void setJe_potrebnoDopunitiFreon(boolean je_potrebnoDopunitiFreon) {
		this.je_potrebnoDopunitiFreon = je_potrebnoDopunitiFreon;
	}

	public boolean getJe_aktivan() {
		return je_aktivan;
	}

	public void setJe_aktivan(boolean je_aktivan) {
		this.je_aktivan = je_aktivan;
	}

	public void prikaziPodatke() {
		System.out.println("---------------------");
		System.out.println("Sistem solarnog grejanja #" + this.getId_sistema());
		System.out.println("Trenutni protok vode kroz sistem: " + this.getTrenutniProtokVode() + " m3/s");
		System.out.println("Trenutna temperatura vode: " + this.getTrenutnaTemperaturaVode() + " �C");
		System.out.println("Potrebno dopuniti freon: " + (this.getJe_potrebnoDopunitiFreon() ? "DA" : "NE"));
		System.out.println("Status sistema: " + (this.getJe_aktivan() ? "AKTIVAN" : "NEAKTIVAN"));
		System.out.println("---------------------");
	}

	public korisnikoviSistemi getComposite() {
		return null;
	}
}