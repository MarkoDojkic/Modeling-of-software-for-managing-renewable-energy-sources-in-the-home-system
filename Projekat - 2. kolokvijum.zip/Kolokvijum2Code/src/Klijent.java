public class Klijent {

	public static void main(String[] args) {
		solarniPVSistem solar_1kw = new solarniPVSistem(234,"PWM", 48, 0.0, 100, 862200.46, false, false);
		solarniPVSistem solar_2kw = new solarniPVSistem(321, "PWM", 24, 83.34, 89, 1124400.37, true, false);
		solarniPVSistem solar_5kw = new solarniPVSistem(417, "MPPT", 48, 104.16, 68, 447123.567, true, true);
		
		korisnikoviSistemi solarniSistemi = new korisnikoviSistemi();
		solarniSistemi.addChild(solar_1kw);
		solarniSistemi.addChild(solar_2kw);
		solarniSistemi.addChild(solar_5kw);
		
		sistemSolarnogGrejanja solarHeating_2 = new sistemSolarnogGrejanja(774, 7.6, 28.7, false, true);
		sistemSolarnogGrejanja solarHeating_4 = new sistemSolarnogGrejanja(953, 14.12, 35.7, true, true);
		korisnikoviSistemi sistemiSolarnogGrejanja = new korisnikoviSistemi();
		sistemiSolarnogGrejanja.addChild(solarHeating_2);
		sistemiSolarnogGrejanja.addChild(solarHeating_4);
		
		eolskiSistem wind_15kw = new eolskiSistem(104,15,96,156.25,75115.0,true);
		eolskiSistem wind_30kw = new eolskiSistem(108,0,96,0.0,30000.0,false);
		korisnikoviSistemi eolskiSistemi = new korisnikoviSistemi();
		eolskiSistemi.addChild(wind_15kw);
		eolskiSistemi.addChild(wind_30kw);
		
		korisnikoviSistemi sistemiOIE = new korisnikoviSistemi();
		sistemiOIE.addChild(solarniSistemi);
		sistemiOIE.addChild(sistemiSolarnogGrejanja);
		sistemiOIE.addChild(eolskiSistemi);
		
		System.out.println("Izvestaj korisnika #447:");
		sistemiOIE.prikaziPodatke();
	}
}
