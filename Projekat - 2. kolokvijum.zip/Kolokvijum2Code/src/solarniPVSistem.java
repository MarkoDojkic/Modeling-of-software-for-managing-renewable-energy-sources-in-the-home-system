public class solarniPVSistem extends sistemOIE {
	private int id_sistema, radniNapon, napunjenostAkumulatora;
	private String tipKontrolera;
	private double jacinaStruje, ukupnaProizvedenaSnaga;
	private boolean je_aktivan, je_prikljucenNaMrezu;

	public solarniPVSistem(int id_sistema, String tipKontrolera,
			int radniNapon, double jacinaStruje, int napunjenostAkumulatora,
			double ukupnaProizvedenaSnaga, boolean je_prikljucenNaMrezu,
			boolean je_aktivan) {
		super();
		this.id_sistema = id_sistema;
		this.tipKontrolera = tipKontrolera;
		this.radniNapon = radniNapon;
		this.jacinaStruje = jacinaStruje;
		this.napunjenostAkumulatora = napunjenostAkumulatora;
		this.ukupnaProizvedenaSnaga = ukupnaProizvedenaSnaga;
		this.je_prikljucenNaMrezu = je_prikljucenNaMrezu;
		this.je_aktivan = je_aktivan;
	}

	public int getId_sistema() {
		return id_sistema;
	}

	public void setId_sistema(int id_sistema) {
		this.id_sistema = id_sistema;
	}

	public String getTipKontrolera() {
		return tipKontrolera;
	}

	public void setTipKontrolera(String tipKontrolera) {
		this.tipKontrolera = tipKontrolera;
	}

	public int getRadniNapon() {
		return radniNapon;
	}

	public void setRadniNapon(int radniNapon) {
		this.radniNapon = radniNapon;
	}

	public double getJacinaStruje() {
		return jacinaStruje;
	}

	public void setJacinaStruje(double jacinaStruje) {
		this.jacinaStruje = jacinaStruje;
	}

	public int getNapunjenostAkumulatora() {
		return napunjenostAkumulatora;
	}

	public void setNapunjenostAkumulatora(int napunjenostAkumulatora) {
		this.napunjenostAkumulatora = napunjenostAkumulatora;
	}

	public double getUkupnaProizvedenaSnaga() {
		return ukupnaProizvedenaSnaga;
	}

	public void setUkupnaProizvedenaSnaga(double ukupnaProizvedenaSnaga) {
		this.ukupnaProizvedenaSnaga = ukupnaProizvedenaSnaga;
	}

	public boolean getJe_aktivan() {
		return je_aktivan;
	}

	public void setJe_aktivan(boolean je_aktivan) {
		this.je_aktivan = je_aktivan;
	}

	public boolean getJe_prikljucenNaMrezu() {
		return je_prikljucenNaMrezu;
	}

	public void setJe_prikljucenNaMrezu(boolean je_prikljucenNaMrezu) {
		this.je_prikljucenNaMrezu = je_prikljucenNaMrezu;
	}

	public void prikaziPodatke() {
		System.out.println("---------------------");
		System.out.println("Solarni sistem #" + this.getId_sistema());
		System.out.println("Tip kontrolera: " + this.getTipKontrolera());
		System.out.println("Radni napon: " + this.getRadniNapon() + "V");
		System.out.println("Jacina struje: " + this.getJacinaStruje() + "A");
		System.out.println("Napunjenost akumulatora: " + this.getNapunjenostAkumulatora() + "%");
		System.out.printf("Ukupna proizvodnja: %.2f kWh\n", this.getUkupnaProizvedenaSnaga()/1000.0);
		System.out.println("Status sistema: " + (this.getJe_aktivan() ? "AKTIVAN" : "NEAKTIVAN"));
		System.out.println("Prikljucen na distributivnu mrezu: " + (this.getJe_prikljucenNaMrezu() ? "DA" : "NE"));
		System.out.println("---------------------");
	}

	public korisnikoviSistemi getComposite() {
		return null;
	}
}